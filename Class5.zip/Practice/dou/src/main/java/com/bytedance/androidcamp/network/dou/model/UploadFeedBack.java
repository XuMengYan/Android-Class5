package com.bytedance.androidcamp.network.dou.model;

import com.google.gson.annotations.SerializedName;

public class UploadFeedBack {

    @SerializedName("success")
    public boolean successful;

}
